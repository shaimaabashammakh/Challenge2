//
//  Challenge2App.swift
//  Challenge2
//
//  Created by Shaima Bashammakh 
//

import SwiftUI

@main
struct Challenge2App: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
